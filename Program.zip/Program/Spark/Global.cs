﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Spark
{
    public static class Global
    {
        public static SqlConnection conexion;
    }
}
